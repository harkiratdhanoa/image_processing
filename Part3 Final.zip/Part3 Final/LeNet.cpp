#include <iostream>
#include <fstream>
#include <vector>
#include <chrono>
#include <math.h>
#include "Pooling.h"
#include "NonLinear.h"
#include "Convolution.h"
#include "Sigmoid.h"
#include "Read.h"
#include "Read2.h"
using namespace std;

typedef vector<float> row;
typedef vector<row> Matrix;
typedef vector<Matrix> VolumeMatrix;
typedef vector<float> Vector;

void add_bias(VolumeMatrix* input, Vector* bias)
{
    for(int i = 0; i<(*input).size(); i++)
        for(int j = 0; j<(*input)[0].size();j++)
            for(int k = 0; k<(*input)[0][0].size();k++)
                (*input)[i][j][k] += (*bias)[i];
}

void volume_convolution(VolumeMatrix* input, VolumeMatrix* filter, Matrix* output)
{
    int N = (*input)[0].size();
    int F = (*filter)[0].size();
    int depth = (*input).size();

    Matrix temp;

    for(int i = 0; i<depth;i++){
        temp = convolution(&((*input)[i]), &((*filter)[i]), 3, 2);
        for(int k = 0; k<N-F+1; k++)
                for(int l = 0; l<N-F+1; l++)
                    (*output)[k][l] += temp[k][l];        
    }
}

void max(Vector probab)
{
    int index[10];
    for(int i = 0; i<10; i++)
        index[i] = i;
    int flips = 1;
    int temp;
    float temp2;
    while(flips!=0){
        flips = 0;
        for(int i = 0; i<9;i++){
            if(probab[i]<probab[i+1]){
                temp = index[i];
                index[i] = index[i+1];
                index[i+1] = temp;
                temp2 = probab[i];
                probab[i] = probab[i+1];
                probab[i+1] = temp2;
                flips++;
            }
        }
    }
    for(int i = 0; i<5; i++){
        cout << "Digit:"<< index[i] << "  ";
        cout << probab[i] << "\n";
    }
}


void Layer1_Conv1(Matrix* input, VolumeMatrix* output)
{
    VolumeMatrix filter_array[20];
    Vector bias(20);
    Filter_Read("conv1.txt", filter_array, &bias, 5, 1, 20);

    VolumeMatrix a(1, Matrix(28, row(28)));
    a[0] = (*input);
    for(int i = 0; i<20; i++){
        volume_convolution(&a, &(filter_array[i]), &((*output)[i]));
    }/*
    for(int i = 0; i<20; i++){
        (*output)[i] = convolution(input, &(filter_array[i][0]), 3, 5);
    }*/
    add_bias(output, &bias);
}

void Layer2_MaxPool(VolumeMatrix* input, VolumeMatrix* output)
{
    for(int i = 0; i<20; i++)
        (*output)[i] = Pooling((*input)[i], true, 2, 2);
}

void Layer3_Conv2(VolumeMatrix* input, VolumeMatrix* output)
{
    VolumeMatrix filter_array[50];
    Vector bias(50);
    Filter_Read("conv2.txt", filter_array, &bias, 5, 20, 50);

    for(int i = 0; i<50; i++){
        volume_convolution(input, &(filter_array[i]), &((*output)[i]));
    }
    add_bias(output, &bias);
}

void Layer4_MaxPool(VolumeMatrix* input, VolumeMatrix* output)
{
    for(int i = 0; i<50; i++)
        (*output)[i] = Pooling((*input)[i], true, 2, 2);
}

void Layer5_FC1_Relu(VolumeMatrix* input, VolumeMatrix* output)
{
    VolumeMatrix filter_array[500];
    Vector bias(500);
    Filter_Read("fc1.txt", filter_array, &bias, 4, 50, 500);

    for(int i = 0; i<500; i++){
        volume_convolution(input, &(filter_array[i]), &((*output)[i]));
    }
    add_bias(output, &bias);
    for(int i = 0; i<500; i++){
        (*output)[i] = NonLinear(&((*output)[i]), true);
    }
}

void Layer6_FC2_Relu(VolumeMatrix* input, VolumeMatrix* output)
{
    VolumeMatrix filter_array[10];
    Vector bias(10);
    Filter_Read("fc2.txt", filter_array, &bias, 1, 500, 10);

    for(int i = 0; i<10; i++){
        volume_convolution(input, &(filter_array[i]), &((*output)[i]));
    }
    add_bias(output, &bias);
    /*for(int i = 0; i<10; i++){
        (*output)[i] = NonLinear(&((*output)[i]), true);
    }*/
}

void Layer7_Softmax(VolumeMatrix* input, Vector* output)
{
    for(int i = 0; i<10;i++)
    {
        (*output)[i] = (*input)[i][0][0];
    }
    (*output) = softmax(*output);
}

int main(int argc, char** argv)
{
    /*int count = 1;	//ignore ./LeNet
    if(argc == 1){
        cout << "Please enter a file name\n";
        return 0;
    }
    string filename = argv[count];*/
    Matrix input = Matrix_Read("images/data.txt");
            
    VolumeMatrix layer1(20, Matrix(24, row(24)));
    Layer1_Conv1(&input, &layer1);

    VolumeMatrix layer2(20, Matrix(12, row(12)));
    Layer2_MaxPool(&layer1, &layer2);

    VolumeMatrix layer3(50, Matrix(8, row(8)));
    Layer3_Conv2(&layer2, &layer3);

    VolumeMatrix layer4(50, Matrix(4, row(4)));
    Layer4_MaxPool(&layer3, &layer4);

    VolumeMatrix layer5(500, Matrix(1, row(1)));
    Layer5_FC1_Relu(&layer4, &layer5);

    VolumeMatrix layer6(10, Matrix(1, row(1)));
    Layer6_FC2_Relu(&layer5, &layer6);

    Vector layer7(10);
    Layer7_Softmax(&layer6, &layer7);

    cout << "Top 5 Digits:\n";
    max(layer7);
    
}