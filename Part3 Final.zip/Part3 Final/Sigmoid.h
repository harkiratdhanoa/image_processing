#include <vector>
#include <math.h>
using namespace std;
typedef vector<float> row;
typedef vector<row> Matrix;

vector<float> sigmoid(vector<float> v);
vector<float> softmax(vector<float> v);