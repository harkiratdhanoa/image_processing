python preprocess.py $1
./LeNet