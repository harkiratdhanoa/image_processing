#include <iostream>
#include <fstream>
#include <vector>
#include <math.h>
using namespace std;

typedef vector<float> row;
typedef vector<row> Matrix;
typedef vector<Matrix> VolumeMatrix;
typedef vector<float> Vector;

void Filter_Read(string filename, VolumeMatrix* filter_array, Vector* bias, int filter_size, int depth, int number_of_filters);
