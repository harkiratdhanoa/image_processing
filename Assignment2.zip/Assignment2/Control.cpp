#include <iostream>
#include <fstream>
#include <vector>
#include <math.h>
#include "Road.h"
#include "Vehicle.h"
using namespace std;
typedef vector<Vehicle> ListOfVehicles;

int main()
{
    Road MainRoad(40, 10);
    
    Vehicle bus(6, 4, "Bus", 1, 1, 0, &MainRoad);
    bus.setPosition(25, 3);
    Vehicle car(4, 2, "Car", 1, 1, 0, &MainRoad);
    car.setPosition(13, 5);
    Vehicle kar(3, 2, "Kar", 1, 1, 0, &MainRoad);
    kar.setPosition(12, 1);
    Vehicle biker(5, 1, "Scooter", 1, 1, 0, &MainRoad);
    biker.setPosition(1, 2);
    
    for(int time = 1; time <= 20; time++)
    {
        cout << "Time: " << time << "\n";
        for(int i = MainRoad.Width-1; i>=0; i--){
            for(int j = MainRoad.Length-1; j>=0;j--){
                if(MainRoad.m[i][j] != NULL){
                    if((*(MainRoad.m[i][j])).Time < time){
                        (*(MainRoad.m[i][j])).Time = time;
                        (*(MainRoad.m[i][j])).kinematicUpdate();
                    }
                }
            }
        }
        for(int i = 0; i<10; i++){
            for(int j = 0; j<40; j++){
                if((MainRoad.m[i][j]) == NULL)
                    cout << " ";
                else 
                    cout << (*(MainRoad.m[i][j])).Type.at(0);
            }

            cout <<"|";
            cout << "\n";
            
        }
    }
}