#include <iostream>
#include <fstream>
#include <vector>
#include <math.h>
#include <unistd.h>
#include "Road.h"
#include "Vehicle.h"
using namespace std;
typedef vector<Vehicle*> lane;
typedef vector<lane> Matrix;

Vehicle::Vehicle(bool is)
{
    isVehicle = is;
    Type = " ";
    Length = 0;
    Width = 0;
    Velocity = 0;
    Acceleration = 0;
    string Type;
    Time = 0;
    closestX = 0;
}

Vehicle::Vehicle(int L, int W, string T, float V, float A, int t, Road* r)
{
    Length = L;
    Width = W;
    Velocity = V;
    Acceleration = A;
    Type = T;
    road = r; 
    Time = t;
    isVehicle = true;
    closestX = 0;
}

void Vehicle::setPosition(int newX, int newY)
{
    currentX = newX;
    currentY = newY;
    RoadUpdate();
    UpdateNeighbours();
}
void Vehicle::setVelocity(float newV){
    Velocity = newV;
}
void Vehicle::setAcceleration(float newA){
    Acceleration = newA;
}
void Vehicle::kinematicUpdate()
{
    currentX = currentX + (Velocity) + (Acceleration)/2;
    Velocity = Velocity + Acceleration;
    RoadUpdate();
    UpdateNeighbours();
    //AccelerationDecide();
}
void Vehicle::RoadUpdate()
{
    for(int i = 0; i< (*road).Length; i++){
        for(int j = 0; j< (*road).Width; j++){
            if((*road).m[j][i] == this){
                (*road).m[j][i] = NULL;
            }
        }
    }
    
    for(int i = 0; i< Length; i++){
        for(int j = 0; j< Width; j++){
            if(currentX-i >=0 && currentX-i < (*road).Length && currentY+j >= 0 && currentY+j < (*road).Width){
                (*road).m[currentY+j][currentX-i] = this;
            }
        }
    }
    return;
}
void Vehicle::UpdateNeighbours()
{
    for(int i = currentX+1; i<(*road).Length; i++)
    {
        for(int j = currentY; j<currentY+Width; j++)
        {
            if(j<(*road).Width)
                if((*road).m[j][i] != NULL){
                    closestX = i;
                    goto label;
                }
        }
    }
    label: return;
}
void Vehicle::AccelerationDecide()
{
    if(closestX == 0)
    {
        Acceleration = 1;
    }
    else if(closestX > currentX && closestX < (*road).Length){
        float possible_acc = ((closestX - currentX) - Velocity)/2;
        Acceleration = possible_acc;
    }
}