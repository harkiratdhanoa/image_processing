#include <iostream>
#include <fstream>
#include <vector>
#include <math.h>
#include "Road.h"
#include "Vehicle.h"
using namespace std;
typedef vector<Vehicle*> lane;
typedef vector<lane> Matrix;

Road::Road()
{
    Length = 1;
    Width = 1;
}

Road::Road(int l, int w)
{
    Vehicle temp(false);
     Length = l;
     Width = w;
     lane Lane;
     for(int i = 0; i< l; i++)
        Lane.push_back(NULL);
     for(int i = 0; i< w; i++)
        m.push_back(Lane);
}


