#include <vector>
using namespace std;
class Vehicle;

typedef vector<Vehicle*> lane;
typedef vector<lane> Matrix;

class Road
{
    public:
    int Length;
    int Width;
    Matrix m;
    Road();
    Road(int l, int w, int SP);
    int SignalPosition;
    char SignalColour;
};