#include <iostream>
#include <fstream>
#include <vector>
#include <math.h>
#include <cstdlib>
#include <unistd.h>
#include "Road.h"
#include "Vehicle.h"
using namespace std;
typedef vector<Vehicle*> lane;
typedef vector<lane> Matrix;

Vehicle::Vehicle(int L, int W, string T, float V, float A, float MV, float MA, int ROP, int LOP, int t, Road* r)
{
    Length = L;
    Width = W;
    Velocity = V;
    Acceleration = A;
    MaxVelocity = MV;
    MaxAcceleration = MA;
    Type = T;
    road = r; 
    Time = t;
    isVehicle = true;
    closestX = 0;
    closestXV = NULL;
    RightClear = false;
    LeftClear = false;
    closestRightX = 0;
    closestRightXV = NULL;
    closestLeftX = 0;
    closestLeftXV = NULL;
    count = rand();
    Initialised = false;
    RightOvertakingProb = ROP;
    LeftOvertakingProb = LOP;
}

void Vehicle::setPosition(int newX, int newY)
{
    currentX = newX;
    currentY = newY;
    RoadUpdate();
    UpdateNeighbours();
}
void Vehicle::setVelocity(float newV){
    Velocity = newV;
}
void Vehicle::setAcceleration(float newA){
    Acceleration = newA;
}
void Vehicle::kinematicUpdate()
{
    if((Velocity) + (Acceleration)/2 >= 0)
        currentX = currentX + (Velocity) + (Acceleration)/2;
    RoadUpdate();
    UpdateNeighbours();
    if(ShouldIRightOvertake())
        currentY = currentY +1;
    else if(ShouldILeftOvertake()){
        currentY = currentY-1;}
    AccelerationDecide();
}
void Vehicle::RoadUpdate()
{
    for(int i = 0; i< (*road).Length; i++){
        for(int j = 0; j< (*road).Width; j++){
            if((*road).m[j][i] == this){
                (*road).m[j][i] = NULL;
            }
        }
    }
    
    for(int i = 0; i< Length; i++){
        for(int j = 0; j< Width; j++){
            if(currentX-i >=0 && currentX-i < (*road).Length && currentY+j >= 0 && currentY+j < (*road).Width){
                (*road).m[currentY+j][currentX-i] = this;
            }
        }
    }
    return;
}
void Vehicle::UpdateNeighbours()
{
    for(int i = currentX+1; i<(*road).Length; i++)
    {
        for(int j = currentY; j<currentY+Width; j++)
        {
            if(j<(*road).Width)
                if((*road).m[j][i] != NULL){
                    closestX = i;
                    closestXV = (*road).m[j][i];
                    goto next;
                }
        }
    }
    closestXV = NULL;
    closestX = -1;
    next: 
    if(currentY+Width >= (*road).Width)
        RightClear = false;
    else{
        for(int j = currentX+2; j>currentX-Length-2; j--)
        {
            if(j >=0 && j<(*road).Length){
                if((*road).m[currentY+Width][j] != NULL){
                    RightClear = false;
                    goto next2;
                }
            }
        }
        RightClear = true;
    }
    next2:
    if(currentY <= 0)
        LeftClear = false;
    else{
        for(int j = currentX+2; j>currentX-Length-2; j--)
        {
            if(j >=0 && j<(*road).Length){
                if((*road).m[currentY-1][j] != NULL){
                    LeftClear = false;
                    goto next3;
                }
            }
        }
        LeftClear = true;
    }
    next3:
    if(currentY+Width >= (*road).Width){
        closestRightX = -2;
        closestRightXV = NULL;
    }
    else{
        for(int j = currentX+1; j<(*road).Length; j++)
        {
            if((*road).m[currentY+Width][j] != NULL){
                closestRightXV = (*road).m[currentY+Width][j];
                closestRightX = j;
                goto next4;
            }
        }

    closestRightX = -1;
    closestRightXV = NULL;
    }
    next4:
    if(currentY <= 0){
        closestLeftX = -2;
        closestLeftXV = NULL;
    }
    else{
        for(int j = currentX+1; j<(*road).Length; j++)
        {
            if((*road).m[currentY-1][j] != NULL){
                closestLeftXV = (*road).m[currentY-1][j];
                closestLeftX = j;
                goto next5;
            }
        }

        closestLeftX = -1;
        closestLeftXV = NULL;
    }
    next5: 
    return;
}
void Vehicle::AccelerationDecide()
{
    int barricade;
    if((*road).SignalColour == 'R')
    {
         if((*road).SignalPosition < closestX && (*road).SignalPosition >= currentX)
            barricade = (*road).SignalPosition;
        else if(closestX == -1 && (*road).SignalPosition >= currentX)
            barricade = (*road).SignalPosition;
        else
            barricade = closestX;
    }
    else
        barricade = closestX;
    int tempVelocity;
    int tempAcceleration;
    float percent = float(rand() % 25 + 75)/100;
    if(barricade == -1)
    {
        tempAcceleration = percent* MaxAcceleration;
        tempVelocity = tempAcceleration + Velocity;
        if(tempVelocity > MaxVelocity)
        {
            tempVelocity = MaxVelocity;
            tempAcceleration = 0;
        }
    }
    else
    {
        barricade = barricade-4;
        tempAcceleration =(((barricade - currentX) - Velocity)*2)/3;
        tempAcceleration = percent* tempAcceleration;
        tempVelocity = Velocity + tempAcceleration;
        if(tempVelocity > MaxVelocity)
        {
            tempVelocity = MaxVelocity;
            tempAcceleration = 0;
        }
    }
    Velocity = tempVelocity;
    Acceleration = tempAcceleration;
}
bool Vehicle::ShouldIRightOvertake()
{
    bool ret;
    if(closestX == -1 || closestX - currentX >= 8)
        ret = false;
    else if (closestRightXV != NULL) ret = isThereRightSpace(closestRightXV) && RightClear;
    else ret = isThereRightSpace(closestXV) && RightClear;
    count = (count+1)%RightOvertakingProb;
    return (count == 0)&&ret;
}
bool Vehicle::ShouldILeftOvertake()
{
    bool ret;
    if(closestX == -1 || closestX - currentX >= 8)
        ret = false;
    else if (closestLeftXV != NULL) ret = isThereLeftSpace(closestLeftXV) && LeftClear;
    else ret = isThereLeftSpace(closestXV) && LeftClear;
    count = (count+1)%LeftOvertakingProb;
    return (count == 0)&&ret;
}
bool Vehicle::isThereRightSpace(Vehicle* v)
{
    if ((*v).currentY + (*v).Width + Width >= (*road).Width){
        return false;
    }
    else if((*v).currentX-(*v).Length+1 >= 0){
        for(int i = 0; i<Width; i++)
        {
            if((*road).m[(*v).currentY + (*v).Width + i][(*v).currentX-(*v).Length+1] != NULL)
            {    return false; }
        }
    }
    return true;
}
bool Vehicle::isThereLeftSpace(Vehicle* v)
{
    if ((*v).currentY - Width < 0){
        return false;
    }
    else if((*v).currentX-(*v).Length+1 >= 0){
        for(int i = 0; i<Width; i++)
        {
            if((*road).m[(*v).currentY - Width + i][(*v).currentX-(*v).Length+1] != NULL)
            {    return false; }
        }
    }
    return true;
}