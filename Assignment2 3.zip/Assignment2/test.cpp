#include <iostream>
#include <fstream>
#include <vector>
#include <math.h>
#include <string>
#include <sstream>
#include <algorithm> 
#include <chrono>
#include <stdlib.h>
#include <unistd.h>
#include <regex>
#include "Road.h"
#include "Vehicle.h"
#include "VehicleType.h"
using namespace std;
typedef vector<VehicleType> List;

void split(const string &s, char delim, vector<string> &elems) {
    stringstream ss(s);
    string item;
    while (getline(ss, item, delim)) {
        elems.push_back(item);
    }
}


vector<string> split(const string &s, char delim) {
    vector<string> elems;
    split(s, delim, elems);
    return elems;
}

int FreeEntry(Road MainRoad, int Width)
{
    int i = 0;
    vector<int> random;
    for(int k = 0; k< MainRoad.Width - Width+1; k++)
        random.push_back(k);
    for(int k = 0; k< MainRoad.Width - Width+1; k++)
    {
        i = random[k];
        for(int j = 0; j< Width; j++)
        {
            if(MainRoad.m[i+j][0] != NULL)
                goto cont;
        }
        i = k;
        goto done;
        cont: continue;
    }
    done: 
    return i;
}
