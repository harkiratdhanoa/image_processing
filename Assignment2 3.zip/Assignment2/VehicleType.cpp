#include <iostream>
#include <fstream>
#include <vector>
#include <math.h>
#include <unistd.h>
#include "VehicleType.h"
using namespace std;

VehicleType::VehicleType(string T,int L, int W,  float MV, float MA, int ROP,int LOP)
{
    Length = L;
    Width = W;
    MaxVelocity = MV;
    MaxAcceleration = MA;
    Type = T;
    RightOvertakingProb = ROP;
    LeftOvertakingProb = LOP;
}
