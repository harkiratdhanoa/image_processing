using namespace std;
class Vehicle
{
    public:
    int Length;
    int Width;
    float Velocity;
    float Acceleration;
    float MaxAcceleration;
    float MaxVelocity;
    string Type;
    int Time;
    bool isVehicle;
    Road* road;
    int currentX; 
    int currentY;
    //Vehicle(bool is);
    Vehicle(int L, int W, string T, float V, float A, float MV, float MA, int ROP, int LOP, int t, Road* r);
    void kinematicUpdate();
    
    bool RightClear;
    bool LeftClear;
    int closestRightX;
    int closestLeftX;
    int closestX;
    int count;
    bool Initialised;
    Vehicle* closestXV;
    Vehicle* closestRightXV;
    Vehicle* closestLeftXV;
    int RightOvertakingProb;
    int LeftOvertakingProb;

    void setPosition(int newX, int newY);
    void setVelocity(float newV);
    void setAcceleration(float newA);
    void RoadUpdate();
    void UpdateNeighbours();
    void AccelerationDecide();
    bool ShouldILeftOvertake();
    bool ShouldIRightOvertake();
    bool isThereRightSpace(Vehicle* v);
    bool isThereLeftSpace(Vehicle* v);
};