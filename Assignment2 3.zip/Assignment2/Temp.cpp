#include <iostream>
#include <fstream>
#include <vector>
#include <math.h>
#include <tuple>
#include <random>
#include <string>
#include <sstream>
#include <algorithm> 
#include <chrono>
#include <stdlib.h>
#include <unistd.h>
#include <regex>
#include <random>
#include "Road.h"
#include "Vehicle.h"
#include "VehicleType.h"
using namespace std;
typedef vector<VehicleType> List;

void split(const string &s, char delim, vector<string> &elems) {
    stringstream ss(s);
    string item;
    while (getline(ss, item, delim)) {
        elems.push_back(item);
    }
}


vector<string> split(const string &s, char delim) {
    vector<string> elems;
    split(s, delim, elems);
    return elems;
}

int FreeEntry(Road MainRoad, int Width)
{
    cout << "1\n";
    int i = 0;
    int k;
    vector<int> list;
    for(k = 0; k< MainRoad.Width - Width+1; k++)
        list.push_back(k);
    //random_shuffle(list.begin(), list.end());
    for(k = 0; k< MainRoad.Width - Width+1; k++)
    {
        i = list[k];
        for(int j = 0; j< Width; j++)
        {
            if(MainRoad.m[i+j][0] != NULL)
                goto cont1;
        }
        goto done;
        cont1: continue;
    }
    i = k;
    done: return i;
}

void Display(Road MainRoad, int time)
{
    cout << "Time: " << time << "\n";
    for(int j = 0; j<MainRoad.Length;j++)
            if(j == MainRoad.SignalPosition)
                cout << MainRoad.SignalColour;
            else
                cout<<" ";
        cout << "\n";
        for(int j = 0; j<MainRoad.Length;j++)
            cout << '-';     
        cout << "\n";
        for(int i = 0; i<MainRoad.Width; i++){
            for(int j = 0; j<MainRoad.Length; j++){
                if((MainRoad.m[i][j]) == NULL)
                    cout << " ";
                else {
                    if((*(MainRoad.m[i][j])).Time <= time)
                        cout << (*(MainRoad.m[i][j])).Type.at(0);
                    else
                    {
                        cout << " ";
                    }
                }
                    
            }

            cout <<"|";
            cout << "\n";
        }
        for(int j = 0; j<MainRoad.Length;j++)
            cout << '-';     
        cout << "\n";
}

int main()
{
    List ListofVehicleTypes;
    float DefaultVelocity;
    float DefaultAcceleration;
    ifstream myfile;
    string line;
    regex r("[a-zA-z_]*\\s=\\s[0-9]*");
    regex color("[a-zA-z_\\s]*\\s=\\s[0-9]*");
    regex c1("[a-zA-z_\\s]*\\s=\\s");
    regex c2("\\s=\\s[0-9]*");
    regex r1("\\s=\\s[0-9]*");
    regex r2("[a-zA-z_]+\\s=\\s");
    regex rpri("[a-zA-z_]+\\s=\\s[a-zA-z_]+");
    regex r3("\\s=\\s[a-zA-z]+");
    myfile.open("config.ini");
    string type;
    int value;
    string second;
    int road_length;
    int road_width;
    int road_signal;
    float default_maxspeed;
    float default_maxacceleration;
    string vehicle_type;
    string colour;
    string three_word;
    int vehicle_length;
    int vehicle_width;
    float vehicle_maxspeed;
    float vehicle_acceleration;
    vector<string> signal_times;
    vector<Vehicle> VehicleList;
    vector<string> words;
    string clas;
    Road MainRoad;
    int default_ROP = 1;
    int vehicle_ROP;
    int default_LOP = 3;
    int vehicle_LOP;

    while(getline(myfile, line))
    {
        if(regex_match(line, r)){
            type = regex_replace(line, r1, "");
            value = stoi(regex_replace(line, r2, ""));
        }
        else if(regex_match(line, rpri))
        {
            type = regex_replace(line, r3, "");
            second = regex_replace(line, r2, "");

        }
        else if(regex_match(line, color))
        {
            three_word = regex_replace(line, c2, "");
            value = stoi(regex_replace(line, c1, ""));
            words = split(three_word, ' ');
            type = words[0];
            clas = words[1];
            colour = words[2];
        }
        else
        {
            type = "Random";
        }
		words = split(line, ' ');
		type = words[0];
		if(type.compare("Road_Length") == 0 || type.compare("Road_Width")== 0
			|| type.compare("Road_Signal")== 0 || type.compare("Default_MaxSpeed")== 0
			|| type.compare("Default_Acceleration")== 0 || type.compare("Right_Overtaking_Probability")== 0
			|| "Left_Overtaking_Probability")== 0 || type.compare("RED") == 0
			|| type.compare("GREEN") == 0)
            value = words[2];
        else if(type.compare("Vehicle_Type")== 0)
        	second = words[2];
		
		
        if(type.compare("DONE")== 0)
            MainRoad = Road(road_length, road_width, road_signal);
        else if(type.compare("Road_Length") == 0)
        	road_length = value
        else if(type.compare("Road_Width")== 0)
            road_width = value;
        else if(type.compare("Road_Signal")== 0)
            road_signal = value; 
        else if(type.compare("Default_MaxSpeed")== 0)
            default_maxspeed = value;
        else if(type.compare("Default_Acceleration")== 0)
            default_maxacceleration = value;
        else if(type.compare("Right_Overtaking_Probability")== 0)
            default_ROP = value;
        else if(type.compare("Left_Overtaking_Probability")== 0)
            default_LOP = value;
        else if(type.compare("Vehicle_Type")== 0)
        {
            label:
            vehicle_type = second;
            vehicle_maxspeed = default_maxspeed;
            vehicle_acceleration = default_maxacceleration;
            vehicle_ROP = default_ROP;
            vehicle_LOP = default_LOP;
            while(getline(myfile, line))
            {
                if(regex_match(line, r))
                {
                    type = regex_replace(line, r1, "");
                    value = stoi(regex_replace(line, r2, ""));
                }
                else if(regex_match(line, rpri))
                {
                    type = regex_replace(line, r3, "");
                    second = regex_replace(line, r2, "");
                }
                else
                {
                    type = "Random";
                }
                
                if(type.compare("Vehicle_Length")== 0)
                    vehicle_length = value;
                else if(type.compare("Vehicle_Width")== 0)
                    vehicle_width = value;
                else if(type.compare("Vehicle_MaxSpeed")== 0)
                    vehicle_maxspeed = value;
                else if(type.compare("Vehicle_Acceleration")== 0)
                    vehicle_acceleration = value;
                else if(type.compare("Vehicle_Right_Overtaking_Probability")== 0)
                    vehicle_ROP = value;
                else if(type.compare("Vehicle_Left_Overtaking_Probability")== 0)
                    vehicle_LOP = value;
                else
                {
                    VehicleType v(vehicle_type, vehicle_length,vehicle_width, vehicle_maxspeed, vehicle_acceleration, vehicle_ROP, vehicle_LOP);
                    ListofVehicleTypes.push_back(v);
                    if(type.compare("Vehicle_Type")== 0)
                        goto label;
                    else break;;
                }
            }

        }
        else if(type.compare("RED") == 0)
            signal_times.push_back(('R'+ to_string(value)));
        else if(type.compare("GREEN") == 0)
            signal_times.push_back(('G'+ to_string(value)));
        else if(type.compare("Enter") == 0)
        {
            int i = 0;
            for(; i< ListofVehicleTypes.size(); i++)
            {
                if(ListofVehicleTypes[i].Type.compare(clas) == 0)
                    break;
            }
            VehicleType vt = ListofVehicleTypes[i];
            Vehicle v(Vehicle(vt.Length, vt.Width, vt.Type, 1, 1, vt.MaxVelocity, vt.MaxAcceleration, vt.RightOvertakingProb, vt.LeftOvertakingProb, value, &MainRoad));
            VehicleList.push_back(v);
        }
    }
    int vehicle_number_uninitialised = VehicleList.size();
    bool clear;
    for(int time = 0; vehicle_number_uninitialised>0 || (clear == false) ; time++)
    {
        //usleep(200000);
        //system("clear");
        //initialise Vehicles
        for(int i = 0; i<signal_times.size();i++)
        {
            if(stoi(signal_times[i].substr(1, string::npos)) == time)
                MainRoad.SignalColour = signal_times[i].at(0);
        }
        clear = true;
        for(int j = MainRoad.Length-1; j>=0;j--){
            for(int i = MainRoad.Width-1; i>=0; i--){
                if(MainRoad.m[i][j] != NULL){
                    clear = false;
                    if((*(MainRoad.m[i][j])).Time < time){
                        (*(MainRoad.m[i][j])).Time = time;
                        (*(MainRoad.m[i][j])).kinematicUpdate();
                    }
                }
            }
        }
        for(int i = 0; i<VehicleList.size(); i++)
        {
            if(VehicleList[i].Time == time && VehicleList[i].Initialised == false)
            {
                int FP = FreeEntry(MainRoad, VehicleList[i].Width);
                if(FP == MainRoad.Width - VehicleList[i].Width +1) 
                {
                    VehicleList[i].Time = VehicleList[i].Time+1;
                }
                else
                {
                     VehicleList[i].setPosition(0, FP);
                     cout << "Exit\n";
                     VehicleList[i].Initialised = true;
                     VehicleList[i].Time = VehicleList[i].Time+1;
                     vehicle_number_uninitialised--;
                }

                
            }
        }
        Display(MainRoad, time);
    }
}

