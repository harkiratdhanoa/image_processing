#include <iostream>
#include <fstream>
#include <vector>
#include <math.h>
#include <chrono>
#include <stdlib.h>
#include <unistd.h>
#include "Road.h"
#include "Vehicle.h"
using namespace std;
typedef vector<Vehicle> ListOfVehicles;

int main()
{
    Road MainRoad(80, 10, 50);
    
    Vehicle bus(6, 7, "Bus", 0.5, 0.5, 1, 4, 8, 0, &MainRoad);
    bus.setPosition(5, 0);
    Vehicle car(4, 2, "Car", 0.5, 0.5, 4, 5, 8, 0, &MainRoad);
    car.setPosition(12, 4);
    Vehicle kar(3, 2, "Kar", 0.5, 0.5, 4, 5,8, 0, &MainRoad);
    kar.setPosition(17, 3);
    Vehicle biker(5, 1, "Scooter", 0.5, 5, 5, 1, 8,0, &MainRoad);
    biker.setPosition(13, 1);
    Vehicle motor(3, 4, "Motor", 0.5, 5, 5, 5,8, 0, &MainRoad);
    motor.setPosition(23, 2);
    Vehicle cycle(4, 1, "Ycycle", 0.5, 5, 3, 2,8, 0, &MainRoad);
    cycle.setPosition(8, 7);
    Vehicle Zcycle(4, 2, "Zcycle", 0.5, 3, 3, 5,8, 15, &MainRoad);
    
    Vehicle Acycle(4, 1, "Acycle", 0.5, 3, 8, 6, 8,25, &MainRoad);
    //Acycle.setPosition(5, 7);
    Vehicle Bcycle(5, 3, "Xcycle", 0.5, 5, 6, 4,8, 20, &MainRoad);
    //Bcycle.setPosition(1, 2);
    for(int i = 0; i<10; i++){
            for(int j = 0; j<80; j++){
                if((MainRoad.m[i][j]) == NULL)
                    cout << " ";
                else 
                    cout << (*(MainRoad.m[i][j])).Type.at(0);
            }

            cout <<"|";
            cout << "\n";
            
        }
    for(int time = 1; time <= 100; time++)
    {
        if(time == 15)
            Zcycle.setPosition(3, 3);
        else if(time == 20)
            Acycle.setPosition(5, 7);
        else if(time == 25)
            Bcycle.setPosition(1, 2);
        usleep(100000);
        system("clear");
        if(time == 5)
            MainRoad.SignalColour = 'R';
        if(time == 15)
            MainRoad.SignalColour = 'G';
        if(time == 20)
            MainRoad.SignalColour = 'R';
        if(time == 25)
            MainRoad.SignalColour = 'G';
        if(time == 35)
            MainRoad.SignalColour = 'R';
        if(time == 45)
            MainRoad.SignalColour = 'G';
        if(time == 55)
            MainRoad.SignalColour = 'R';
        cout << "Time: " << time << "\n";
        for(int i = MainRoad.Width-1; i>=0; i--){
            for(int j = MainRoad.Length-1; j>=0;j--){
                if(MainRoad.m[i][j] != NULL){
                    if((*(MainRoad.m[i][j])).Time < time){
                        (*(MainRoad.m[i][j])).Time = time;
                        (*(MainRoad.m[i][j])).kinematicUpdate();
                    }
                }
            }
        }
        for(int j = 0; j<MainRoad.Length;j++)
            if(j == MainRoad.SignalPosition)
                cout << MainRoad.SignalColour;
            else
            {
                    cout<<" ";
            }
            
        cout << "\n";
        for(int i = 0; i<10; i++){
            for(int j = 0; j<80; j++){
                if((MainRoad.m[i][j]) == NULL)
                    cout << " ";
                else {
                    if((*(MainRoad.m[i][j])).Time <= time)
                        cout << (*(MainRoad.m[i][j])).Type.at(0);
                    else
                    {
                        cout << " ";
                    }
                }
                    
            }
            cout <<"|";
            cout << "\n";
            
        }
    }
}