using namespace std;
class VehicleType
{
    public:
    int Length;
    int Width;
    float MaxAcceleration;
    float MaxVelocity;
    string Type;
    int RightOvertakingProb;
    int LeftOvertakingProb;

    VehicleType(string T, int L, int W, float MV, float MA, int ROP, int LOP);
};