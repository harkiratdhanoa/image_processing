#include <GLFW/glfw3.h>
#include <iostream>
using namespace std;
static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GLFW_TRUE);
}

int main(){
    if (!glfwInit())
    {
        cout << "Initialization failed";
        glfwTerminate();
        return 0;
    }

    GLFWwindow* window = glfwCreateWindow(640, 480, "My Title", NULL, NULL);
    if (!window)
    {
        cout << "Window failed";
        glfwTerminate();
        return 0;
    }
    glfwMakeContextCurrent(window);
    while (!glfwWindowShouldClose(window))
    {
        glfwSetKeyCallback(window, key_callback);
        int width = 100; int height = 100;
        glfwGetFramebufferSize(window, &width, &height);
        glViewport(0, 0, width, height);
    }
    glfwTerminate();
}