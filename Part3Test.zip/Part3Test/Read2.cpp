#include <iostream>
#include <fstream>
#include <vector>
#include <math.h>
using namespace std;

typedef vector<float> row;
typedef vector<row> Matrix;
typedef vector<Matrix> VolumeMatrix;
typedef vector<float> Vector;

void Filter_Read(string filename, VolumeMatrix* filter_array, Vector* bias, int filter_size, int depth, int number_of_filters)
{
	ifstream myfile;
	myfile.open(filename);
	if(!myfile.fail())		//check if file exists
	{
		for(int i = 0; i<number_of_filters; i++){
			filter_array[i] = VolumeMatrix(depth, Matrix(filter_size, row(filter_size)));
			for(int j = 0; j<depth;j++)
				for(int k = 0; k<filter_size; k++)
					for(int l = 0; l<filter_size; l++)
						myfile >> filter_array[i][j][k][l];
		}
        for(int i = 0; i<number_of_filters; i++){		//begin reading the values into the matrix
			myfile >> (*bias)[i];
		}
		myfile.close();
	}
	else	//throw exception if file absent
		throw filename;
}

/*int main()
{
	Filter filter_array[10];
	Vector bias(10);
	Filter_Read("fc2.txt",filter_array, &bias, 1, 500, 10);
	//for(int i = 0; i<50; i++)
		cout << filter_array[9][499][0][0] << "\n";
		cout << bias[9] << "\n";
	

}*/