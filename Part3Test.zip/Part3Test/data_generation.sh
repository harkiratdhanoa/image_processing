#!/bin/sh
for i in 4 8 16 32 64 128 256 512 1024
do
	for j in 3 5 9 18
	do
		./gen_mat $i
		./fil_mat $j
		for k in 1 2 3 4 5
		do
			./program convolution matrix.txt kernel.txt padding normal >> data/"$i""_""$j""_1".dat
			./program convolution matrix.txt kernel.txt padding mkl >> data/"$i""_""$j""_2".dat
			./program convolution matrix.txt kernel.txt padding openblas >> data/"$i""_""$j""_3".dat
			./program convolution matrix.txt kernel.txt padding pthreads >> data/"$i""_""$j""_4".dat
		done
		./gen_mat $i
		./fil_mat $j
		for k in 1 2 3 4 5
		do
			./program convolution matrix.txt kernel.txt padding normal >> data/"$i""_""$j""_1".dat
			./program convolution matrix.txt kernel.txt padding mkl >> data/"$i""_""$j""_2".dat
			./program convolution matrix.txt kernel.txt padding openblas >> data/"$i""_""$j""_3".dat
			./program convolution matrix.txt kernel.txt padding pthreads >> data/"$i""_""$j""_4".dat
		done
		./gen_mat $i
		./fil_mat $j
		for k in 1 2 3 4 5
		do
			./program convolution matrix.txt kernel.txt padding normal >> data/"$i""_""$j""_1".dat
			./program convolution matrix.txt kernel.txt padding mkl >> data/"$i""_""$j""_2".dat
			./program convolution matrix.txt kernel.txt padding openblas >> data/"$i""_""$j""_3".dat
			./program convolution matrix.txt kernel.txt padding pthreads >> data/"$i""_""$j""_4".dat
		done
		./gen_mat $i
		./fil_mat $j
		for k in 1 2 3 4 5
		do
			./program convolution matrix.txt kernel.txt padding normal >> data/"$i""_""$j""_1".dat
			./program convolution matrix.txt kernel.txt padding mkl >> data/"$i""_""$j""_2".dat
			./program convolution matrix.txt kernel.txt padding openblas >> data/"$i""_""$j""_3".dat
			./program convolution matrix.txt kernel.txt padding pthreads >> data/"$i""_""$j""_4".dat
		done
		./gen_mat $i
		./fil_mat $j
		for k in 1 2 3 4 5
		do
			./program convolution matrix.txt kernel.txt padding normal >> data/"$i""_""$j""_1".dat
			./program convolution matrix.txt kernel.txt padding mkl >> data/"$i""_""$j""_2".dat
			./program convolution matrix.txt kernel.txt padding openblas >> data/"$i""_""$j""_3".dat
			./program convolution matrix.txt kernel.txt padding pthreads >> data/"$i""_""$j""_4".dat
		done
		echo "Looping ... number $i $j" 
	done
done