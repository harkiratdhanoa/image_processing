using namespace std;
class VehicleType
{
    public:
    int Length;
    int Width;
    float MaxAcceleration;
    float MaxVelocity;
    string Type;

    VehicleType(string T, int L, int W, float MV, float MA);
};