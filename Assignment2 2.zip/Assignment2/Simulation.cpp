#include <iostream>
#include <fstream>
#include <vector>
#include <math.h>
#include <string>
#include <sstream>
#include <chrono>
#include <stdlib.h>
#include <unistd.h>
#include <regex>
#include "Road.h"
#include "Vehicle.h"
#include "VehicleType.h"
using namespace std;
typedef vector<VehicleType> List;

void split(const string &s, char delim, vector<string> &elems) {
    stringstream ss(s);
    string item;
    while (getline(ss, item, delim)) {
        elems.push_back(item);
    }
}


vector<string> split(const string &s, char delim) {
    vector<string> elems;
    split(s, delim, elems);
    return elems;
}

int FreeEntry(Road MainRoad, int Width)
{
    int i = 0;
    for(i = 0; i< MainRoad.Width - Width+1; i++)
    {
        for(int j = 0; j< Width; j++)
        {
            if(MainRoad.m[i+j][0] == NULL)
                goto done;
        }
    }
    done: return i;
}

int main()
{
    List ListofVehicleTypes;
    float DefaultVelocity;
    float DefaultAcceleration;
    ifstream myfile;
    string line;
    regex r("[a-zA-z_]*\\s=\\s[0-9]*");
    regex color("[a-zA-z_\\s]*\\s=\\s[0-9]*");
    regex c1("[a-zA-z_\\s]*\\s=\\s");
    regex c2("\\s=\\s[0-9]*");
    regex r1("\\s=\\s[0-9]*");
    regex r2("[a-zA-z_]+\\s=\\s");
    regex rpri("[a-zA-z_]+\\s=\\s[a-zA-z_]+");
    regex r3("\\s=\\s[a-zA-z]+");
    myfile.open("config.ini");
    string type;
    int value;
    string second;
    int road_length;
    int road_width;
    int road_signal;
    float default_maxspeed;
    float default_maxacceleration;
    string vehicle_type;
    string colour;
    string three_word;
    int vehicle_length;
    int vehicle_width;
    float vehicle_maxspeed;
    float vehicle_acceleration;
    vector<int> signal_times;
    vector<Vehicle> VehicleList;
    vector<string> words;
    string clas;
    Road MainRoad;

    while(getline(myfile, line))
    {
        if(regex_match(line, r)){
            type = regex_replace(line, r1, "");
            value = stoi(regex_replace(line, r2, ""));
        }
        else if(regex_match(line, rpri))
        {
            type = regex_replace(line, r3, "");
            second = regex_replace(line, r2, "");

        }
        else if(regex_match(line, color))
        {
            three_word = regex_replace(line, c2, "");
            value = stoi(regex_replace(line, c1, ""));
            words = split(three_word, ' ');
            type = words[0];
            clas = words[1];
            colour = words[2];
        }
        else
        {
            type = "Random";
        }

        if(line.compare("DONE")== 0)
            MainRoad = Road(road_length, road_width, road_signal);
        else if(type.compare("Road_Length") == 0)
            road_length = value;
        else if(type.compare("Road_Width")== 0)
            road_width = value;
        else if(type.compare("Road_Signal")== 0)
            road_signal = value;
        else if(type.compare("Default_MaxSpeed")== 0)
            default_maxspeed = value;
        else if(type.compare("Default_Acceleration")== 0)
            default_maxacceleration = value;
        else if(type.compare("Vehicle_Type")== 0)
        {
            label:
            vehicle_type = second;
            vehicle_maxspeed = default_maxspeed;
            vehicle_acceleration = default_maxacceleration;
            while(getline(myfile, line))
            {
                if(regex_match(line, r))
                {
                    type = regex_replace(line, r1, "");
                    value = stoi(regex_replace(line, r2, ""));
                }
                else if(regex_match(line, rpri))
                {
                    type = regex_replace(line, r3, "");
                    second = regex_replace(line, r2, "");
                }
                else
                {
                    type = "Random";
                }
                
                if(type.compare("Vehicle_Length")== 0)
                    vehicle_length = value;
                else if(type.compare("Vehicle_Width")== 0)
                    vehicle_width = value;
                else if(type.compare("Vehicle_MaxSpeed")== 0)
                    vehicle_maxspeed = value;
                else if(type.compare("Vehicle_Acceleration")== 0)
                    vehicle_acceleration = value;
                else
                {
                    VehicleType v(vehicle_type, vehicle_length,vehicle_width, vehicle_maxspeed, vehicle_acceleration);
                    ListofVehicleTypes.push_back(v);
                    if(type.compare("Vehicle_Type")== 0)
                        goto label;
                    else break;;
                }
            }

        }
        else if(type.compare("RED") == 0)
            signal_times.push_back(-value);
        else if(type.compare("GREEN") == 0)
            signal_times.push_back(value);
        else if(type.compare("Enter") == 0)
        {
            int i = 0;
            for(; i< ListofVehicleTypes.size(); i++)
            {
                if(ListofVehicleTypes[i].Type.compare(clas) == 0)
                    break;
            }
            VehicleType vt = ListofVehicleTypes[i];
            Vehicle v(Vehicle(vt.Length, vt.Width, vt.Type, 1, 1, vt.MaxVelocity, vt.MaxAcceleration, value, &MainRoad));
            VehicleList.push_back(v);
        }
        
        
    }
    cout << MainRoad.Length;

    int vehicle_point = 0;
    for(int time = 0; time <= 100; time++)
    {
        usleep(100000);
        system("clear");
        if(vehicle_point < VehicleList.size())
        {
            if(VehicleList[vehicle_point].Time >= time)
            {
                int FP = FreeEntry(MainRoad, VehicleList[vehicle_point].Width);
                if(FP == MainRoad.Width - VehicleList[vehicle_point].Width +1) 
                {
                    VehicleList[vehicle_point].Time = VehicleList[vehicle_point].Time+1;
                }
                else
                {
                    VehicleList[vehicle_point].setPosition(0, FP);
                    vehicle_point++;
                }
                
            }
        }
        for(int i = MainRoad.Width-1; i>=0; i--){
            for(int j = MainRoad.Length-1; j>=0;j--){
                if(MainRoad.m[i][j] != NULL){
                    if((*(MainRoad.m[i][j])).Time < time){
                        (*(MainRoad.m[i][j])).Time = time;
                        (*(MainRoad.m[i][j])).kinematicUpdate();
                    }
                }
            }
        }
        for(int i = 0; i<MainRoad.Width; i++){
            for(int j = 0; j<MainRoad.Length; j++){
                if((MainRoad.m[i][j]) == NULL)
                    cout << " ";
                else {
                    if((*(MainRoad.m[i][j])).Time <= time)
                        cout << (*(MainRoad.m[i][j])).Type.at(0);
                    else
                    {
                        cout << " ";
                    }
                }
                    
            }

            cout <<"|";
            cout << "\n";
            
        }

    }
    /*Road MainRoad(80, 10, 50);
    
    Vehicle bus(6, 4, "Bus", 0.5, 0.5, 2, 4, 0, &MainRoad);
    bus.setPosition(5, 0);
    Vehicle car(4, 2, "Car", 0.5, 0.5, 4, 5, 0, &MainRoad);
    car.setPosition(12, 4);
    Vehicle kar(3, 2, "Kar", 0.5, 0.5, 4, 5, 0, &MainRoad);
    kar.setPosition(17, 6);
    Vehicle biker(5, 1, "Scooter", 0.5, 5, 5, 1, 0, &MainRoad);
    biker.setPosition(13, 2);
    Vehicle motor(4, 4, "Motor", 0.5, 5, 5, 5, 0, &MainRoad);
    motor.setPosition(23, 6);
    Vehicle cycle(4, 1, "Ycycle", 0.5, 5, 1, 2, 0, &MainRoad);
    cycle.setPosition(8, 7);
    Vehicle Zcycle(4, 5, "Zcycle", 0.5, 3, 3, 5, 15, &MainRoad);
    Zcycle.setPosition(3, 3);
    Vehicle Acycle(4, 1, "Acycle", 0.5, 3, 8, 6, 25, &MainRoad);
    Acycle.setPosition(5, 7);
    Vehicle Bcycle(5, 3, "Bcycle", 0.5, 5, 6, 4, 20, &MainRoad);
    Bcycle.setPosition(1, 2);
    for(int i = 0; i<10; i++){
            for(int j = 0; j<80; j++){
                if((MainRoad.m[i][j]) == NULL)
                    cout << " ";
                else 
                    cout << (*(MainRoad.m[i][j])).Type.at(0);
            }

            cout <<"|";
            cout << "\n";
            
        }
    for(int time = 1; time <= 100; time++)
    {
        usleep(100000);
        system("clear");
        if(time == 5)
            MainRoad.SignalColour = 'R';
        if(time == 15)
            MainRoad.SignalColour = 'G';
        if(time == 20)
            MainRoad.SignalColour = 'R';
        if(time == 25)
            MainRoad.SignalColour = 'G';
        if(time == 35)
            MainRoad.SignalColour = 'R';
        if(time == 45)
            MainRoad.SignalColour = 'G';
        if(time == 55)
            MainRoad.SignalColour = 'R';
        cout << "Time: " << time << "\n";
        for(int i = MainRoad.Width-1; i>=0; i--){
            for(int j = MainRoad.Length-1; j>=0;j--){
                if(MainRoad.m[i][j] != NULL){
                    if((*(MainRoad.m[i][j])).Time < time){
                        (*(MainRoad.m[i][j])).Time = time;
                        (*(MainRoad.m[i][j])).kinematicUpdate();
                    }
                }
            }
        }
        for(int j = 0; j<MainRoad.Length;j++)
            if(j == MainRoad.SignalPosition)
                cout << MainRoad.SignalColour;
            else
            {
                    cout<<" ";
            }
            
        cout << "\n";
        for(int i = 0; i<10; i++){
            for(int j = 0; j<80; j++){
                if((MainRoad.m[i][j]) == NULL)
                    cout << " ";
                else {
                    if((*(MainRoad.m[i][j])).Time <= time)
                        cout << (*(MainRoad.m[i][j])).Type.at(0);
                    else
                    {
                        cout << " ";
                    }
                }
                    
            }

            cout <<"|";
            cout << "\n";
            
        }
    }*/
}