#include <iostream>
#include <fstream>
#include <vector>
#include <math.h>
#include <chrono>
#include <stdlib.h>
#include <unistd.h>
#include <regex>
#include "Road.h"
#include "Vehicle.h"
using namespace std;
typedef vector<Vehicle> List;

int main()
{
    List ListofVehicleTypes;
    float DefaultVelocity;
    float DefaultAcceleration;
    ifstream myfile;
    string line;
    regex r("[a-zA-z_]*\\s=\\s[0-9]*");
    regex r1("\\s=\\s[0-9]*");
    regex r2("[a-zA-z_]*\\s=\\s");
    regex rpri("[a-zA-z_]*\\s=\\s[a-zA-z_]*");
    regex r3("[a-zA-z_]*\\s=\\s");
    myfile.open("config.ini");
    string type;
    int value;
    string second;
    int road_length;
    int road_width;
    int road_signal;
    float default_maxspeed;
    float default_maxacceleration;
    string vehicle_type;
    int vehicle_length;
    int vehicle_width;
    float vehicle_maxspeed;
    float vehicle_acceleration;

    while(getline(myfile, line))
    {
        if(regex_match(line, r)){
            type = regex_replace(line, r1, "");
            value = stoi(regex_replace(line, r2, ""));
            cout << type << " " << value << "\n";
        }
        else if(regex_match(line, rpri))
        {
            type = regex_replace(line, r1, "");
            second = regex_replace(line, r3, "");
        }
        else
        {
            type = "Random";
        }
        
        if(type.compare("Road_Length") == 0)
            road_length = value;
        else if(type.compare("Road_Width")== 0)
            road_width = value;
        else if(type.compare("Road_Signal")== 0)
            road_signal = value;
        else if(type.compare("Default_MaxSpeed")== 0)
            default_maxspeed = value;
        else if(type.compare("Default_Acceleration")== 0)
            default_maxacceleration = value;
        else if(type.compare("Vehicle_Type")== 0)
        {
            label:
            vehicle_type = second;
            vehicle_maxspeed = default_maxspeed;
            vehicle_acceleration = default_maxacceleration;
            while(getline(myfile, line))
            {
                if(regex_match(line, r))
                {
                    type = regex_replace(line, r1, "");
                    value = stoi(regex_replace(line, r2, ""));
                }
                else if(regex_match(line, rpri))
                {
                    type = regex_replace(line, r1, "");
                    second = regex_replace(line, r3, "");
                }
                if(type.compare("Vehicle_Length")== 0)
                    vehicle_length = value;
                else if(type.compare("Vehicle_Width")== 0)
                    vehicle_width = value;
                else if(type.compare("Vehicle_MaxSpeed")== 0)
                    vehicle_maxspeed = value;
                else if(type.compare("Vehicle_Acceleration")== 0)
                    vehicle_acceleration = value;
                else
                {
                    ListofVehicleTypes.push_back(VehicleType(vehicle_type, vehicle_length,vehicle_width, vehicle_maxspeed, vehicle_acceleration));
                    if(type.compare("Vehicle_Type")== 0)
                        goto label;
                    else goto next;
                }
                
            }

        }
        next: continue;
    }

    cout << road_length << " " << road_width << " " << road_signal << "\n";
    



    /*Road MainRoad(80, 10, 50);
    
    Vehicle bus(6, 4, "Bus", 0.5, 0.5, 2, 4, 0, &MainRoad);
    bus.setPosition(5, 0);
    Vehicle car(4, 2, "Car", 0.5, 0.5, 4, 5, 0, &MainRoad);
    car.setPosition(12, 4);
    Vehicle kar(3, 2, "Kar", 0.5, 0.5, 4, 5, 0, &MainRoad);
    kar.setPosition(17, 6);
    Vehicle biker(5, 1, "Scooter", 0.5, 5, 5, 1, 0, &MainRoad);
    biker.setPosition(13, 2);
    Vehicle motor(4, 4, "Motor", 0.5, 5, 5, 5, 0, &MainRoad);
    motor.setPosition(23, 6);
    Vehicle cycle(4, 1, "Ycycle", 0.5, 5, 1, 2, 0, &MainRoad);
    cycle.setPosition(8, 7);
    Vehicle Zcycle(4, 5, "Zcycle", 0.5, 3, 3, 5, 15, &MainRoad);
    Zcycle.setPosition(3, 3);
    Vehicle Acycle(4, 1, "Acycle", 0.5, 3, 8, 6, 25, &MainRoad);
    Acycle.setPosition(5, 7);
    Vehicle Bcycle(5, 3, "Bcycle", 0.5, 5, 6, 4, 20, &MainRoad);
    Bcycle.setPosition(1, 2);
    for(int i = 0; i<10; i++){
            for(int j = 0; j<80; j++){
                if((MainRoad.m[i][j]) == NULL)
                    cout << " ";
                else 
                    cout << (*(MainRoad.m[i][j])).Type.at(0);
            }

            cout <<"|";
            cout << "\n";
            
        }
    for(int time = 1; time <= 100; time++)
    {
        usleep(100000);
        system("clear");
        if(time == 5)
            MainRoad.SignalColour = 'R';
        if(time == 15)
            MainRoad.SignalColour = 'G';
        if(time == 20)
            MainRoad.SignalColour = 'R';
        if(time == 25)
            MainRoad.SignalColour = 'G';
        if(time == 35)
            MainRoad.SignalColour = 'R';
        if(time == 45)
            MainRoad.SignalColour = 'G';
        if(time == 55)
            MainRoad.SignalColour = 'R';
        cout << "Time: " << time << "\n";
        for(int i = MainRoad.Width-1; i>=0; i--){
            for(int j = MainRoad.Length-1; j>=0;j--){
                if(MainRoad.m[i][j] != NULL){
                    if((*(MainRoad.m[i][j])).Time < time){
                        (*(MainRoad.m[i][j])).Time = time;
                        (*(MainRoad.m[i][j])).kinematicUpdate();
                    }
                }
            }
        }
        for(int j = 0; j<MainRoad.Length;j++)
            if(j == MainRoad.SignalPosition)
                cout << MainRoad.SignalColour;
            else
            {
                    cout<<" ";
            }
            
        cout << "\n";
        for(int i = 0; i<10; i++){
            for(int j = 0; j<80; j++){
                if((MainRoad.m[i][j]) == NULL)
                    cout << " ";
                else {
                    if((*(MainRoad.m[i][j])).Time <= time)
                        cout << (*(MainRoad.m[i][j])).Type.at(0);
                    else
                    {
                        cout << " ";
                    }
                }
                    
            }

            cout <<"|";
            cout << "\n";
            
        }
    }*/
}