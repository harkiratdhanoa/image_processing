using namespace std;
class Vehicle
{
    public:
    int Length;
    int Width;
    float Velocity;
    float Acceleration;
    float MaxAcceleration;
    float MaxVelocity;
    string Type;
    int Time;
    bool isVehicle;
    int closestX;

    Road* road;

    int currentX; 
    int currentY;
    int frontX;
    int rightY;

    Vehicle(bool is);
    Vehicle(int L, int W, string T, float V, float A, float MV, float MA, int t, Road* r);
    void setPosition(int newX, int newY);
    void setVelocity(float newV);
    void setAcceleration(float newA);
    void kinematicUpdate();
    void RoadUpdate();
    void UpdateNeighbours();
    void AccelerationDecide();
};