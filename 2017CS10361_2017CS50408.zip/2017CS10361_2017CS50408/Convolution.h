#include <iostream>
#include <fstream>
#include <vector>
#include <math.h>
using namespace std;

typedef vector<float> row;
typedef vector<row> Matrix;
typedef vector<float> Vector;
Matrix Image_Mult_Form(Matrix* image, int filter_size);
Matrix Filter_Mult_Form(Matrix* filter);	
Matrix Reverse_Mat_Mult_Form;
Matrix Matrix_Mult(Matrix* m1, Matrix* m2);
Matrix Padded_Image(Matrix* image, int filter_size, int image_row_no, int image_column_no, int custom_border_size = 0);
Matrix convolution(Matrix* image, Matrix* filter, int padded =1, bool mult = false, int custom_border_size = 0);